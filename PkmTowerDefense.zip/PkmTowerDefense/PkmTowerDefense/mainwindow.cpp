#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QPainter>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    m_dlgOption = new DlgOption(this);
    connect(m_dlgOption, SIGNAL(sglCloseGame()), this, SLOT(sltCloseGame()));
    connect(m_dlgOption, SIGNAL(sglStartGame()), this, SLOT(sltStartGame()));
    m_dlgOption->show();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *)
{
        QPixmap pix;
        pix.load(":/Res/Res/map.png");
        QPainter painter(this);
        painter.drawPixmap(0, 0, pix);
}

void MainWindow::sltUpdateMap()
{
    update();
}

//待实现
void MainWindow::sltStartGame()
{

}

void MainWindow::sltCloseGame()
{
    this->close();
}



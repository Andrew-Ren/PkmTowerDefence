/********************************************************************************
** Form generated from reading UI file 'DlgOption.ui'
**
** Created by: Qt User Interface Compiler version 5.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DLGOPTION_H
#define UI_DLGOPTION_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DlgOption
{
public:
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QVBoxLayout *verticalLayout;
    QPushButton *pb_Start;
    QPushButton *pb_NextLevel;
    QPushButton *pb_Exit;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QWidget *DlgOption)
    {
        if (DlgOption->objectName().isEmpty())
            DlgOption->setObjectName(QStringLiteral("DlgOption"));
        DlgOption->resize(1280, 767);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(DlgOption->sizePolicy().hasHeightForWidth());
        DlgOption->setSizePolicy(sizePolicy);
        horizontalLayout = new QHBoxLayout(DlgOption);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(184, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        pb_Start = new QPushButton(DlgOption);
        pb_Start->setObjectName(QStringLiteral("pb_Start"));
        sizePolicy.setHeightForWidth(pb_Start->sizePolicy().hasHeightForWidth());
        pb_Start->setSizePolicy(sizePolicy);
        pb_Start->setMinimumSize(QSize(180, 90));
        pb_Start->setMaximumSize(QSize(180, 90));

        verticalLayout->addWidget(pb_Start);

        pb_NextLevel = new QPushButton(DlgOption);
        pb_NextLevel->setObjectName(QStringLiteral("pb_NextLevel"));
        sizePolicy.setHeightForWidth(pb_NextLevel->sizePolicy().hasHeightForWidth());
        pb_NextLevel->setSizePolicy(sizePolicy);
        pb_NextLevel->setMinimumSize(QSize(180, 90));
        pb_NextLevel->setMaximumSize(QSize(180, 90));

        verticalLayout->addWidget(pb_NextLevel);

        pb_Exit = new QPushButton(DlgOption);
        pb_Exit->setObjectName(QStringLiteral("pb_Exit"));
        sizePolicy.setHeightForWidth(pb_Exit->sizePolicy().hasHeightForWidth());
        pb_Exit->setSizePolicy(sizePolicy);
        pb_Exit->setMinimumSize(QSize(180, 90));
        pb_Exit->setMaximumSize(QSize(180, 90));

        verticalLayout->addWidget(pb_Exit);


        horizontalLayout->addLayout(verticalLayout);

        horizontalSpacer_2 = new QSpacerItem(183, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);


        retranslateUi(DlgOption);

        QMetaObject::connectSlotsByName(DlgOption);
    } // setupUi

    void retranslateUi(QWidget *DlgOption)
    {
        DlgOption->setWindowTitle(QApplication::translate("DlgOption", "Form", Q_NULLPTR));
        pb_Start->setText(QString());
        pb_NextLevel->setText(QApplication::translate("DlgOption", "\344\270\213\344\270\200\345\205\263", Q_NULLPTR));
        pb_Exit->setText(QApplication::translate("DlgOption", "\351\200\200\345\207\272", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class DlgOption: public Ui_DlgOption {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DLGOPTION_H

#ifndef DLGOPTION_H
#define DLGOPTION_H

#include <QWidget>

//该类的作用是作为主菜单界面，实现界面之间的切换

namespace Ui {
class DlgOption;
}

class DlgOption : public QWidget
{
    Q_OBJECT

public:
    explicit DlgOption(QWidget *parent = 0);
    ~DlgOption();
    void showNextPb();

signals:
    void sglStartGame();
    void sglNextLevel();
    void sglCloseGame();

protected:
    void paintEvent(QPaintEvent *);

private slots:
    void on_pb_Start_clicked();

    void on_pb_NextLevel_clicked();

    void on_pb_Exit_clicked();

private:
    Ui::DlgOption *ui;

};

#endif // DLGOPTION_H

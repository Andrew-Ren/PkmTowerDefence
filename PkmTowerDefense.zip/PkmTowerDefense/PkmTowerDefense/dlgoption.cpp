#include "DlgOption.h"
#include "ui_DlgOption.h"
#include <QPainter>
#include <QSize>

//游戏初始化时绘制主菜单，只显示开始按钮，将下一关和退出按钮隐藏
DlgOption::DlgOption(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DlgOption)
{
    ui->setupUi(this);
    ui->pb_Start->setIcon(QIcon(":/Res/Res/start.png"));
    ui->pb_Start->setIconSize(QSize(180,90));
    ui->pb_Start->setStyleSheet("background-color: rgba(0, 0, 0, 0)");
    ui->pb_NextLevel->hide();
    ui->pb_Exit->hide();
}

DlgOption::~DlgOption()
{
    delete ui;
}

void DlgOption::on_pb_Start_clicked()
{
    this->hide();   //点击开始按钮后，将主菜单界面隐藏，关卡界面出现
    emit sglStartGame();
}

void DlgOption::on_pb_NextLevel_clicked()
{
    this->hide();
    emit sglNextLevel();
}

void DlgOption::on_pb_Exit_clicked()
{
    emit sglCloseGame();
}

//该函数在程序第一次运行时会自动调用，同时在调用update()函数时也会自动调用该函数
void DlgOption::paintEvent(QPaintEvent *)
{
    QPixmap pix;
    pix.load(":/Res/Res/cover.png");
    QPainter painter(this);
    painter.drawPixmap(QRect(0, 0, width(), height()), pix);
}

void DlgOption::showNextPb()
{
    ui->pb_NextLevel->show();
}

